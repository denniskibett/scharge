@extends('layouts.app')

@section('content')
        <!-- ===== Main Content Start ===== -->
        <main>
          <div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
            <!-- Breadcrumb Start -->
            <div x-data="{ pageName: `Bar Chart`}">
              @include('partials.breadcrumb')
            </div>
            <!-- Breadcrumb End -->

            <div class="space-y-6">
              <div
                class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]"
              >
                <div class="px-6 py-5">
                  <h3
                    class="text-base font-medium text-gray-800 dark:text-white/90"
                  >
                    Bar Chart 1
                  </h3>
                </div>
                <div
                  class="p-5 border-t border-gray-100 dark:border-gray-800 sm:p-6"
                >
                  <!-- ====== Bar Chart One Start -->
                  <div class="max-w-full overflow-x-auto custom-scrollbar">
                    <div id="chartOne" class="min-w-[1000px]"></div>
                  </div>
                  <!-- ====== Bar Chart One End -->
                </div>
              </div>
            </div>
          </div>
        </main>
        <!-- ===== Main Content End ===== -->
@endsection