@extends('layouts.app')

@section('content')

        <!-- ===== Main Content Start ===== -->
        <main>
            <!-- Breadcrumb Start -->
            <div x-data="{ pageName: `Blank Page`}">
              @include('partials.breadcrumb')
            </div>
            <!-- Breadcrumb End -->

            <div
              class="min-h-screen rounded-2xl border border-gray-200 bg-white px-5 py-7 dark:border-gray-800 dark:bg-white/[0.03] xl:px-10 xl:py-12"
            >
              <div class="mx-auto w-full max-w-[630px] text-center">
                <h3
                  class="mb-4 text-theme-xl font-semibold text-gray-800 dark:text-white/90 sm:text-2xl"
                >
                  Card Title Here
                </h3>

                <p
                  class="text-sm text-gray-500 dark:text-gray-400 sm:text-base"
                >
                  Start putting content on grids or panels, you can also use
                  different combinations of grids. Please check out the
                  dashboard and other pages
                </p>
              </div>
            </div>
        </main>
        <!-- ===== Main Content End ===== -->
        @endsection