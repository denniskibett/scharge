<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
  <title>mtickets — events, travel, stream & sports</title>
  <!-- Google Fonts + Font Awesome + Swiper -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
  <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    html { scroll-behavior: smooth; }
    body { font-family:'Inter',sans-serif; background:#fafcfa; color:#1a2c1a; line-height:1.4; }
    :root {
      --mt-green: rgb(53,168,57);
      --mt-green-dark: #2a7a2e;
      --mt-navy: oklch(0.35 0.08 240.87);
      --mt-soft-bg: #f8faf8;
      --mt-card-bg: #ffffff;
    }
    .container { max-width:1280px; margin:0 auto; padding:0 32px; }
    /* header transparent */
    .navbar { display:flex; justify-content:space-between; align-items:center; padding:24px 0; flex-wrap:wrap; gap:20px; z-index:30; background:transparent; }
    .logo { display:flex; align-items:center; gap:10px; font-weight:800; font-size:1.8rem; }
    .logo-icon { background:var(--mt-green); width:40px; height:40px; border-radius:20px; display:flex; align-items:center; justify-content:center; color:white; font-size:1.4rem; box-shadow:0 10px 15px -3px rgba(0,0,0,0.1); }
    .logo span { background:linear-gradient(135deg, var(--mt-navy), var(--mt-green)); background-clip:text; -webkit-background-clip:text; color:transparent; }
    .nav-links { display:flex; gap:28px; font-weight:600; flex-wrap:wrap; }
    .nav-links a { text-decoration:none; color:#1f2a1f; transition:color 0.2s; font-size:0.95rem; cursor:pointer; }
    .nav-links a:hover { color:var(--mt-green); }
    .glass-btn { background:rgba(255,255,255,0.75); backdrop-filter:blur(12px); border:1px solid rgba(255,255,255,0.5); padding:8px 22px; border-radius:48px; font-weight:600; color:var(--mt-navy); transition:all 0.25s; cursor:pointer; box-shadow:0 2px 8px rgba(0,0,0,0.02); }
    .glass-btn:hover { background:var(--mt-green); color:white; border-color:var(--mt-green); transform:translateY(-2px); }
    /* hero slider full */
    .hero-slider-full { position:relative; width:100vw; left:50%; right:50%; margin-left:-50vw; margin-right:-50vw; margin-top:-80px; margin-bottom:60px; overflow:hidden; height:100vh; min-height:700px; }
    .swiper { width:100%; height:100%; }
    .swiper-slide { position:relative; width:100%; height:100%; overflow:hidden; }
    .slide-bg { width:100%; height:100%; object-fit:cover; display:block; transition:transform 6s ease-out; }
    .swiper-slide-active .slide-bg { transform:scale(1.05); }
    .slide-overlay { position:absolute; top:0; left:0; width:100%; height:100%; background:linear-gradient(135deg, rgba(0,0,0,0.5) 0%, rgba(0,0,0,0.3) 100%); display:flex; flex-direction:column; justify-content:center; align-items:center; text-align:center; color:white; padding:0 24px; }
    .slide-category { background:var(--mt-green); display:inline-block; padding:8px 28px; border-radius:60px; font-size:0.9rem; font-weight:700; letter-spacing:1px; margin-bottom:24px; box-shadow:0 6px 14px rgba(0,0,0,0.2); animation:fadeInUp 0.7s ease-out; }
    .slide-overlay h2 { font-size:4rem; font-weight:800; margin-bottom:20px; max-width:80%; text-shadow:0 4px 20px rgba(0,0,0,0.4); line-height:1.2; animation:fadeInUp 0.7s ease-out 0.1s both; }
    .slide-desc { font-size:1.25rem; opacity:0.95; margin-bottom:36px; max-width:55%; text-shadow:0 2px 10px rgba(0,0,0,0.3); animation:fadeInUp 0.7s ease-out 0.2s both; }
    .slide-btn { background:white; color:var(--mt-navy); border:none; padding:14px 44px; border-radius:60px; font-weight:700; font-size:1rem; display:inline-flex; align-items:center; gap:12px; transition:0.25s; cursor:pointer; box-shadow:0 12px 24px rgba(0,0,0,0.2); animation:fadeInUp 0.7s ease-out 0.3s both; }
    .slide-btn:hover { background:var(--mt-green); color:white; transform:translateY(-4px); }
    @keyframes fadeInUp { from { opacity:0; transform:translateY(30px);} to { opacity:1; transform:translateY(0);} }
    .swiper-pagination-bullet { background:white; opacity:0.6; width:10px; height:10px; }
    .swiper-pagination-bullet-active { background:var(--mt-green) !important; opacity:1; transform:scale(1.2); }

    /* bottom service bar on slider */
    .slider-bottom-nav {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      background: rgba(0,0,0,0.6);
      backdrop-filter: blur(10px);
      padding: 16px 24px;
      display: flex;
      justify-content: center;
      gap: 40px;
      flex-wrap: wrap;
      z-index: 20;
      border-top: 1px solid rgba(255,255,255,0.15);
    }
    .slider-bottom-nav a {
      color: white;
      text-decoration: none;
      font-weight: 600;
      font-size: 1rem;
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px 18px;
      border-radius: 40px;
      transition: 0.2s;
      background: rgba(255,255,255,0.05);
      border: 1px solid transparent;
      cursor: pointer;
    }
    .slider-bottom-nav a i { font-size: 1.2rem; }
    .slider-bottom-nav a:hover { background: var(--mt-green); border-color: white; transform: translateY(-3px); }
    .slider-bottom-nav a.active-nav { background: var(--mt-green); border-color: white; }

    /* welcome message - centered */
    .welcome-message { text-align:center; margin:30px auto 56px; display:flex; flex-direction:column; align-items:center; justify-content:center; }
    .welcome-message h1 { font-size:3rem; font-weight:800; background:linear-gradient(135deg, var(--mt-navy), var(--mt-green)); background-clip:text; -webkit-background-clip:text; color:transparent; }
    .welcome-message p { font-size:1.2rem; color:#4c6a4c; max-width:680px; margin:16px auto 0; }
    .section-anchor { scroll-margin-top:100px; display:block; }
    /* category header */
    .category-header { display:flex; align-items:baseline; justify-content:space-between; flex-wrap:wrap; margin-bottom:28px; margin-top:20px; border-bottom:2px solid #eef3ea; padding-bottom:12px; }
    .category-header h2 { font-size:2rem; font-weight:700; color:var(--mt-navy); display:inline-flex; align-items:center; gap:12px; }
    /* filter bar */
    .filter-bar { display:flex; flex-wrap:wrap; gap:16px; margin-bottom:24px; align-items:center; background:#f0f5ee; padding:12px 20px; border-radius:60px; }
    .filter-bar input, .filter-bar select { border:none; background:white; padding:10px 18px; border-radius:40px; font-family:inherit; font-size:0.9rem; flex:1 1 200px; outline:1px solid #dce8da; transition:0.2s; }
    .filter-bar input:focus, .filter-bar select:focus { outline:2px solid var(--mt-green); }
    .filter-bar button { background:var(--mt-green); color:white; border:none; padding:10px 28px; border-radius:40px; font-weight:600; cursor:pointer; transition:0.2s; }
    .filter-bar button:hover { background:var(--mt-green-dark); }
    /* cards grid */
    .event-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(280px,1fr)); gap:32px; margin-bottom:56px; }
    .event-card { background:var(--mt-card-bg); border-radius:32px; overflow:hidden; box-shadow:0 15px 30px -12px rgba(0,0,0,0.05); transition:all 0.3s; border:1px solid #eef3ea; cursor:default; }
    .event-card:hover { transform:translateY(-6px); box-shadow:0 25px 35px -14px rgba(53,168,57,0.15); border-color:var(--mt-green); }
    .event-img { width:100%; aspect-ratio:1/0.85; object-fit:cover; display:block; background:#eef3ea; }
    .event-info { padding:20px 22px 26px; background:white; }
    .event-cat { display:inline-block; background:#e9f5e8; color:var(--mt-green-dark); font-size:0.7rem; font-weight:700; padding:5px 14px; border-radius:40px; margin-bottom:12px; }
    .event-title { font-size:1.2rem; font-weight:700; margin-bottom:6px; color:#1e2a1e; }
    .event-meta { display:flex; justify-content:space-between; align-items:center; margin-top:16px; }
    .price { font-weight:800; color:var(--mt-green); font-size:1.25rem; }
    .book-link { background:var(--mt-navy); color:white; padding:8px 18px; border-radius:40px; font-size:0.8rem; font-weight:600; transition:0.2s; cursor:pointer; border:none; }
    .book-link:hover { background:var(--mt-green); }
    /* travel specific (redbus inspired) */
    .travel-card { background:white; border-radius:24px; padding:16px; display:flex; gap:16px; align-items:center; border:1px solid #e6f0e4; transition:0.2s; }
    .travel-card:hover { border-color:var(--mt-green); box-shadow:0 8px 18px rgba(0,0,0,0.04); }
    .travel-icon { background:#e9f5e8; width:56px; height:56px; border-radius:20px; display:flex; align-items:center; justify-content:center; font-size:1.8rem; color:var(--mt-green); flex-shrink:0; }
    .travel-detail { flex:1; }
    .travel-detail h4 { font-weight:700; font-size:1.1rem; }
    .travel-detail p { color:#5e7a5e; font-size:0.9rem; }
    .travel-price { font-weight:700; color:var(--mt-green); }
    .travel-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(300px,1fr)); gap:20px; margin-bottom:56px; }
    /* CTA */
    .cta-section { background:var(--mt-navy); border-radius:48px; margin:30px 0 70px; padding:56px 48px; text-align:center; color:white; }
    .btn-cta { background:var(--mt-green); color:white; border:none; padding:14px 40px; border-radius:60px; font-weight:700; margin-top:24px; font-size:1rem; cursor:pointer; }
    .btn-cta:hover { background:#3fc544; transform:scale(1.02); }
    footer { border-top:1px solid #e6f0e4; padding:40px 0; text-align:center; color:#6e8b6e; background:white; }
    /* service hide/show */
    .service-section { transition: opacity 0.3s ease; }
    .service-section.hidden { display: none; }
    @media (max-width:780px) { .container { padding:0 20px; } .hero-slider-full { height:70vh; min-height:450px; margin-top:-60px; } .slide-overlay h2 { font-size:2rem; max-width:95%; } .slide-desc { max-width:85%; font-size:1rem; } .welcome-message h1 { font-size:2rem; } .navbar { flex-direction:column; } .nav-links { justify-content:center; gap:18px; } .slider-bottom-nav { gap:16px; padding:12px; } .slider-bottom-nav a { font-size:0.8rem; padding:6px 12px; } }
  </style>
</head>
<body>
<header class="container">
  <div class="navbar">
    <div class="logo"><div class="logo-icon"><i class="fas fa-ticket-alt"></i></div><span>mtickets</span></div>
    <!-- NAV TABS -->
    <div class="nav-links">
      <a href="#" data-target="events-sports"><i class="fas fa-calendar-alt"></i> Events & Sports</a>
      <a href="#" data-target="stream-cinema"><i class="fas fa-film"></i> Stream & Cinema</a>
      <a href="#" data-target="travel"><i class="fas fa-bus"></i> Travel</a>
      <a href="#" data-target="all" class="active-nav"><i class="fas fa-th"></i> All</a>
    </div>
    <div><button class="glass-btn"><i class="fas fa-user-circle"></i> Sign in</button></div>
  </div>
</header>

<main>
  <!-- HERO SLIDER with bottom nav -->
  <div class="hero-slider-full">
    <div class="swiper mySwiper">
      <div class="swiper-wrapper">
        <div class="swiper-slide"><img class="slide-bg" src="https://picsum.photos/id/106/2400/1600" alt="festival"><div class="slide-overlay"><span class="slide-category"><i class="fas fa-music"></i> FESTIVAL</span><h2>Glastonbury 2025 · The pilgrimage</h2><p class="slide-desc">Iconic performances & community. Secure your pass.</p><button class="slide-btn">Grab tickets →</button></div></div>
        <div class="swiper-slide"><img class="slide-bg" src="https://picsum.photos/id/13/2400/1600" alt="flight"><div class="slide-overlay"><span class="slide-category"><i class="fas fa-plane-departure"></i> FLIGHTS</span><h2>Summer escapes from $39</h2><p class="slide-desc">Compare 500+ airlines, flexible change.</p><button class="slide-btn">Find flights →</button></div></div>
        <div class="swiper-slide"><img class="slide-bg" src="https://picsum.photos/id/24/2400/1600" alt="sports"><div class="slide-overlay"><span class="slide-category"><i class="fas fa-futbol"></i> SPORTS</span><h2>Champions League Final · NBA</h2><p class="slide-desc">Live matches, premium seats available.</p><button class="slide-btn">Book now →</button></div></div>
      </div>
      <div class="swiper-pagination"></div>
    </div>
    <!-- BOTTOM 20% SERVICE NAVIGATION -->
    <div class="slider-bottom-nav">
      <a data-target="events-sports" class="active-nav"><i class="fas fa-calendar-alt"></i> Events & Sports</a>
      <a data-target="stream-cinema"><i class="fas fa-film"></i> Stream & Cinema</a>
      <a data-target="travel"><i class="fas fa-bus"></i> Travel</a>
      <a data-target="all"><i class="fas fa-th"></i> All</a>
    </div>
  </div>

  <!-- WELCOME (centered) -->
  <div class="container welcome-message">
    <h1>One place for all your journeys & experiences.</h1>
    <p>We're here to fill your life with joy — from last-minute concert tickets to weekend getaways and family movie nights.</p>
  </div>

  <!-- ========== 1. EVENTS & SPORTS ========== -->
  <div id="events-sports" class="container section-anchor service-section">
    <div class="category-header"><h2><i class="fas fa-calendar-alt" style="color:var(--mt-green);"></i> Events & Sports</h2><a href="#">View all →</a></div>
    <div class="filter-bar">
      <input type="text" id="esSearch" placeholder="Search events, teams..." oninput="filterCards('es')">
      <select id="esFilter" onchange="filterCards('es')"><option value="all">All categories</option><option value="concert">Concert</option><option value="festival">Festival</option><option value="theatre">Theatre</option><option value="basketball">Basketball</option><option value="football">Football</option><option value="grand slam">Grand Slam</option></select>
      <button onclick="filterCards('es')"><i class="fas fa-search"></i> Filter</button>
    </div>
    <div class="event-grid" id="esGrid">
      <div class="event-card" data-cat="concert"><img class="event-img" src="https://picsum.photos/id/29/600/510" alt="Concert"><div class="event-info"><span class="event-cat">Concert</span><div class="event-title">Coldplay: Music Of The Spheres</div><div class="event-meta"><span class="price">from $79</span><button class="book-link">Tickets</button></div></div></div>
      <div class="event-card" data-cat="festival"><img class="event-img" src="https://picsum.photos/id/96/600/510" alt="Festival"><div class="event-info"><span class="event-cat">Festival</span><div class="event-title">Austin City Limits 3-Day Pass</div><div class="event-meta"><span class="price">$295</span><button class="book-link">Get pass</button></div></div></div>
      <div class="event-card" data-cat="theatre"><img class="event-img" src="https://picsum.photos/id/107/600/510" alt="Theatre"><div class="event-info"><span class="event-cat">Theatre</span><div class="event-title">Hamilton Broadway Week</div><div class="event-meta"><span class="price">$89+</span><button class="book-link">Book now</button></div></div></div>
      <div class="event-card" data-cat="basketball"><img class="event-img" src="https://picsum.photos/id/124/600/510" alt="NBA"><div class="event-info"><span class="event-cat">Basketball</span><div class="event-title">NBA Finals: Lakers vs Celtics</div><div class="event-meta"><span class="price">$210+</span><button class="book-link">Get tickets</button></div></div></div>
      <div class="event-card" data-cat="football"><img class="event-img" src="https://picsum.photos/id/131/600/510" alt="Soccer"><div class="event-info"><span class="event-cat">Football</span><div class="event-title">UEFA Champions League Final</div><div class="event-meta"><span class="price">€159</span><button class="book-link">Hospitality</button></div></div></div>
      <div class="event-card" data-cat="grand slam"><img class="event-img" src="https://picsum.photos/id/130/600/510" alt="Tennis"><div class="event-info"><span class="event-cat">Grand Slam</span><div class="event-title">Wimbledon 2025 Centre Court</div><div class="event-meta"><span class="price">£89</span><button class="book-link">Book</button></div></div></div>
    </div>
  </div>

  <!-- ========== 2. STREAM & CINEMA ========== -->
  <div id="stream-cinema" class="container section-anchor service-section">
    <div class="category-header"><h2><i class="fas fa-film" style="color:var(--mt-green);"></i> Movies & Stream</h2><a href="#">View all →</a></div>
    <div class="filter-bar">
      <input type="text" id="scSearch" placeholder="Search movies, streams..." oninput="filterCards('sc')">
      <select id="scFilter" onchange="filterCards('sc')"><option value="all">All genres</option><option value="imax">IMAX</option><option value="live stream">Live stream</option><option value="ballet">Ballet</option><option value="premiere">Premiere</option></select>
      <button onclick="filterCards('sc')"><i class="fas fa-search"></i> Filter</button>
    </div>
    <div class="event-grid" id="scGrid">
      <div class="event-card" data-cat="imax"><img class="event-img" src="https://picsum.photos/id/42/600/510" alt="IMAX"><div class="event-info"><span class="event-cat">IMAX</span><div class="event-title">Dune: Part Two · Premium Laser</div><div class="event-meta"><span class="price">$22.50</span><button class="book-link">Pick seat</button></div></div></div>
      <div class="event-card" data-cat="live stream"><img class="event-img" src="https://picsum.photos/id/90/600/510" alt="Stream"><div class="event-info"><span class="event-cat">Live stream</span><div class="event-title">Global Citizen Festival HD</div><div class="event-meta"><span class="price">$14.99</span><button class="book-link">Stream now</button></div></div></div>
      <div class="event-card" data-cat="ballet"><img class="event-img" src="https://picsum.photos/id/38/600/510" alt="Ballet"><div class="event-info"><span class="event-cat">Ballet</span><div class="event-title">The Nutcracker Live Recording</div><div class="event-meta"><span class="price">$19</span><button class="book-link">Rent</button></div></div></div>
      <div class="event-card" data-cat="premiere"><img class="event-img" src="https://picsum.photos/id/69/600/510" alt="Premiere"><div class="event-info"><span class="event-cat">Premiere</span><div class="event-title">Oscar Season: Anora Exclusive</div><div class="event-meta"><span class="price">$28</span><button class="book-link">Book</button></div></div></div>
    </div>
  </div>

  <!-- ========== 3. TRAVEL (AIR, BUS, TRAIN) – redbus inspired UI ========== -->
  <div id="travel" class="container section-anchor service-section">
    <div class="category-header"><h2><i class="fas fa-bus" style="color:var(--mt-green);"></i> Travel · Air, Train & Bus</h2><a href="#">View all →</a></div>
    <div class="filter-bar">
      <input type="text" id="trSearch" placeholder="Search destination, route..." oninput="filterCards('tr')">
      <select id="trFilter" onchange="filterCards('tr')"><option value="all">All transport</option><option value="flight">Flight</option><option value="train">Train</option><option value="bus">Bus</option></select>
      <button onclick="filterCards('tr')"><i class="fas fa-search"></i> Filter</button>
    </div>
    <div class="travel-grid" id="trGrid">
      <div class="travel-card" data-cat="flight"><div class="travel-icon" style="background:#d4edda; color:#1a7a2e;"><i class="fas fa-plane"></i></div><div class="travel-detail"><h4>NBO → JFK · JamboJet</h4><p>Kenya's airline · 2 stops</p></div><div class="travel-price">$689*</div><button class="book-link" style="margin-left:8px;">Book</button></div>
      <div class="travel-card" data-cat="flight"><div class="travel-icon" style="background:#d4edda; color:#1a7a2e;"><i class="fas fa-plane"></i></div><div class="travel-detail"><h4>NBO → DXB · Kenya Airways</h4><p>Pride of Africa · 5h</p></div><div class="travel-price">$489</div><button class="book-link" style="margin-left:8px;">Reserve</button></div>
      <div class="travel-card" data-cat="train"><div class="travel-icon" style="background:#fff3cd; color:#856404;"><i class="fas fa-train"></i></div><div class="travel-detail"><h4>Mombasa → Nairobi · SGR</h4><p>Madaraka Express · 5h</p></div><div class="travel-price">KSh 1,000</div><button class="book-link" style="margin-left:8px;">Seat</button></div>
      <div class="travel-card" data-cat="bus"><div class="travel-icon" style="background:#cce5ff; color:#004085;"><i class="fas fa-bus"></i></div><div class="travel-detail"><h4>Nairobi → Kisumu · Easy Coach</h4><p>Luxury bus · 6h</p></div><div class="travel-price">KSh 1,800</div><button class="book-link" style="margin-left:8px;">Book</button></div>
      <div class="travel-card" data-cat="train"><div class="travel-icon" style="background:#fff3cd; color:#856404;"><i class="fas fa-train"></i></div><div class="travel-detail"><h4>Nairobi → Kisumu · SGR</h4><p>Scenic route · 6h</p></div><div class="travel-price">KSh 1,200</div><button class="book-link" style="margin-left:8px;">Reserve</button></div>
      <div class="travel-card" data-cat="flight"><div class="travel-icon" style="background:#d4edda; color:#1a7a2e;"><i class="fas fa-plane"></i></div><div class="travel-detail"><h4>NBO → Mombasa · JamboJet</h4><p>Domestic · 1h</p></div><div class="travel-price">$89</div><button class="book-link" style="margin-left:8px;">Grab</button></div>
    </div>
  </div>

  <!-- CTA -->
  <div class="container">
    <div class="cta-section"><h2>Ready to make memories?</h2><p style="font-size:1.1rem;margin-top:8px;">Join millions — mtickets puts you first.</p><button class="btn-cta"><i class="fas fa-smile-wink"></i> Start exploring for free</button><div style="margin-top:20px;font-size:0.85rem;">Zero hidden fees + 5% back in mtickets points</div></div>
  </div>
</main>
<footer>
  <div class="container"><div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:16px;"><div>© 2025 mtickets — designed for you</div><div style="display:flex;gap:24px;"><a href="#" style="color:#6e8b6e;"><i class="fab fa-twitter"></i></a><a href="#" style="color:#6e8b6e;"><i class="fab fa-instagram"></i></a><a href="#" style="color:#6e8b6e;"><i class="fab fa-tiktok"></i></a></div></div><div style="margin-top:28px;font-size:0.75rem;border-top:1px solid #ecf5ea;padding-top:24px;"><p>Your experiences matter — mtickets combines events, sports, movies & travel in one seamless ecosystem.</p></div></div>
</footer>

<script>
  // Swiper
  new Swiper('.mySwiper', { loop:true, autoplay:{delay:6000,disableOnInteraction:false}, pagination:{el:'.swiper-pagination',clickable:true}, speed:1000 });

  // filter function for three sections
  function filterCards(section) {
    let gridId, searchId, filterId;
    if (section === 'es') { gridId='esGrid'; searchId='esSearch'; filterId='esFilter'; }
    else if (section === 'sc') { gridId='scGrid'; searchId='scSearch'; filterId='scFilter'; }
    else if (section === 'tr') { gridId='trGrid'; searchId='trSearch'; filterId='trFilter'; }
    const grid = document.getElementById(gridId);
    const cards = grid.querySelectorAll('.event-card, .travel-card');
    const searchVal = document.getElementById(searchId).value.toLowerCase();
    const filterVal = document.getElementById(filterId).value.toLowerCase();
    cards.forEach(card => {
      const cat = card.dataset.cat || '';
      const title = card.querySelector('.event-title')?.innerText?.toLowerCase() || card.querySelector('.travel-detail h4')?.innerText?.toLowerCase() || '';
      const matchSearch = title.includes(searchVal) || cat.includes(searchVal);
      const matchFilter = filterVal === 'all' || cat === filterVal;
      card.style.display = (matchSearch && matchFilter) ? '' : 'none';
    });
  }

  // booking demo
  document.querySelectorAll('.book-link, .slide-btn, .btn-cta, .glass-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      if(btn.classList.contains('book-link')||btn.classList.contains('slide-btn')||btn.classList.contains('btn-cta')||btn.classList.contains('glass-btn')) {
        e.preventDefault(); alert("✨ Welcome to mtickets! Your adventure awaits — secure checkout, best price guarantee.");
      }
    });
  });

  // SERVICE NAVIGATION: show/hide sections + highlight active
  function showService(target) {
    // hide all sections
    document.querySelectorAll('.service-section').forEach(el => el.classList.add('hidden'));
    // show target or all
    if (target === 'all') {
      document.querySelectorAll('.service-section').forEach(el => el.classList.remove('hidden'));
    } else {
      const section = document.getElementById(target);
      if (section) section.classList.remove('hidden');
    }
    // update nav highlights
    document.querySelectorAll('.nav-links a, .slider-bottom-nav a').forEach(link => {
      link.classList.remove('active-nav');
      if (link.dataset.target === target) link.classList.add('active-nav');
    });
    // if all, highlight the 'all' button
    if (target === 'all') {
      document.querySelectorAll('.nav-links a[data-target="all"], .slider-bottom-nav a[data-target="all"]').forEach(el => el.classList.add('active-nav'));
    }
  }

  // attach click listeners to all nav links (header + slider bottom)
  document.querySelectorAll('.nav-links a, .slider-bottom-nav a').forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const target = this.dataset.target;
      if (target) showService(target);
      // smooth scroll to top of section if not 'all'
      if (target !== 'all') {
        const el = document.getElementById(target);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  });

  // set default: show all
  showService('all');
</script>
</body>
</html>